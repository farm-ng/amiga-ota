from gc import mem_free, collect
collect(); print("-------->", mem_free(), "bytes free before anything <--------")

from os import stat
from sys import path
from supervisor import disable_autoreload

disable_autoreload()

def path_exists(p):
    try:
        stat(p)
    except OSError as e:
        return False
    return True

def path_join(parent: str, child: str):
    parent = parent.rstrip("/")
    child = child.strip("./")
    return '/'.join((parent, child))

def run_app(app_dir):
    if path_exists(path_join(app_dir,"code.mpy")):
        path.insert(0, path_join(app_dir,"lib"))
        path.insert(0, app_dir)
        collect(); print("-------->", mem_free(), "bytes free before import <--------")
        import code
        collect(); 
        x = mem_free()
        print("-------->", x, "bytes free after import <--------")
        # Increase this number if possible.
        if getattr(code, 'DEV', True):
            memory_thresh=26000
            assert x > memory_thresh, 'Please keep atleast %d free for application after import.'%(memory_thresh)
        code.main()

run_app("/app")
#run_app("/updator")
